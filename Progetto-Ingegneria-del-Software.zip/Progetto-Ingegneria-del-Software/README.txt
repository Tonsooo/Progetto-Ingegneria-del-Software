La consegna del progetto è stata gestita come richiesto. Sono presenti quattro cartelle, ciascuna contenente una delle quattro parti del progetto.

In ogni cartella è incluso un file README.txt che fornisce una breve descrizione del contenuto della cartella e altri dettagli rilevanti per la consegna del progetto.

[ Tommaso Becattini   7082245   tommaso.becattini1@stud.unifi.it ]