Per visualizzare meglio le immagini dei diagrammi UML inserite nel PDF, ho inserito i file in formato JPEG all'interno della cartella: Images of UML Diagrams.

Inoltre, nella cartella di questo file è presente il file "UML Diagrams.uml" per aprire i vari diagrammi su StarUML.