# Importazione del Progetto in Eclipse

## Introduzione
Il progetto deve essere importato in Eclipse per poter visualizzare e modificare il codice sorgente. Segui i passaggi qui sotto per completare l'importazione.

## Passaggi per l'Importazione

1. **Apri Eclipse**: Avvia Eclipse sul tuo computer.
2. **Crea un nuovo workspace**: Se non hai già un workspace, creane uno nuovo.
3. **Importa il progetto**:
   - Vai su `File` > `Import...`.
   - Seleziona `Import Projects from File System or Archive` e clicca su `Next`.
   - Clicca su `Archive` e seleziona la cartella del progetto che desideri importare.
   - Clicca su `Finish`.



