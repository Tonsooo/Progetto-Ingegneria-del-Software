# All'interno della cartella sono riportate 3 cartelle:
- After my changes
- Before my changes
- Running Project


## After my changes
La cartella contiene il file excel con le metriche del codice dopo le correzioni, e il risultato del CodeCheck che riporta tutte le violazioni presenti nel codice al termine della correzione.
Inoltre è presente un altro file che riporta le violazioni MISRA e la richiesta di deroga per tali violazioni.


## Before my changes
La cartella contiene il file excel con le metriche del codice e il risultato del CodeCheck che riporta tutte le violazioni presenti nel codice prima della correzione e delle mie modifiche.

## Running project
La cartella contiene i file con la correzione delle violazioni e la cartella .und per poter aprire il progetto su Understand.

Avvio del progetto:
- gcc Axle_Counter.o Train_Movement.o Safe_Print.o Main.o -o Project
- ./Project

