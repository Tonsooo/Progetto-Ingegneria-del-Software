#ifndef AXLE_COUNTER_H
#define AXLE_COUNTER_H

// Track segment status
#define FREE 0          // Track is free
#define OCCUPIED 1      // Track is occupied

// Type definitions
typedef signed int int32_t;
typedef double float64_t;
typedef signed char int8_t;


// Function prototypes
int32_t axle_Counter(int32_t sectionP, int32_t total_wagons); 
int32_t controlloStato(int32_t* ptr);                        
int32_t get_status(void);                                     

void first_axle_pushing(void);    // Handles first axle
void second_axle_pushing(void);   // Handles second axle

float64_t testFunction(float64_t test); 


// External function declarations
extern void first_axle_counter_pushed(void);   
extern void second_axle_counter_pushed(void);  


extern void train_arrives(const int32_t L);
extern void train_leaves(int32_t x);
extern int32_t checkStatus(int32_t* ptr);

#endif /* AXLE_COUNTER_H */
