#include "Axle_Counter.h"
#include "Safe_Print.h"


int32_t static STATUS  = FREE; //initial status of track segment is FREE
int32_t static COUNTED_AXLES  = 0; //how many axles are in the track segment
					

void static printinfo(int32_t a, int32_t counted_axles);

void static printinfo(int32_t a, int32_t counted_axles) {
  safePrintInt("STATUS: ", a);
  safePrintInt("COUNTED_AXLES: ", counted_axles);
}


// Returns track segment STATUS and counted axles
int32_t controlloStato(int32_t* ptr) {
  *ptr = STATUS;
  int32_t counted_axles = COUNTED_AXLES;
  printinfo(*ptr, counted_axles);
  return STATUS;
}


// Increments axle count, sets track to OCCUPIED
void first_axle_counter_pushed(void) {
  COUNTED_AXLES++;
  STATUS = OCCUPIED;
}

// Decrements axle count, updates track status
void second_axle_counter_pushed(void) {
  COUNTED_AXLES --;
  STATUS = (COUNTED_AXLES == 0) ? FREE : OCCUPIED;
}


// Initializes track state based on sectionP value
void static init_Counter(int32_t *sectionP) {
  *sectionP = (*sectionP > 0) ? OCCUPIED : FREE;
  *sectionP = -1;
}

// Commented out unused functions for clarity
// Removed unused functions (c1..c3, f1..f4, this_is_not_used)
