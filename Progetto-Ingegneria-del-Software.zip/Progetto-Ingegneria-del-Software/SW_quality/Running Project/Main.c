#include <stdint.h>
#include <stdio.h>

#include "Axle_Counter.h"
#include "Safe_Print.h"

// Dichiarazioni delle funzioni utilizzate in main


int32_t main(void) {
  int32_t status_value = 0; // Variabile per memorizzare lo stato del binari
  safePrint("project starting\n"); // Messaggio di inizio
  safePrintInt("status track= ", checkStatus(&status_value));
  (void)train_arrives(3); // Train arrives with 3 axles
  safePrintInt("status track= ", checkStatus(&status_value)); 
  (void)train_leaves(3);  // Train leaves with 3 axles
  safePrintInt("status track= ", checkStatus(&status_value)); 
  return 0;
}
