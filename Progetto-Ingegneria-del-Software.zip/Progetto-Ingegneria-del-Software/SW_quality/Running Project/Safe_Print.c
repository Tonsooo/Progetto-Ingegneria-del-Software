#include "Safe_Print.h"

#include <stdio.h>   
#include <stdint.h>   // Include per i tipi di dato come int32_t
#include <string.h>   // Include per funzioni di manipolazione stringhe come strlen

// Funzione per stampare un messaggio su stdout
void safePrint(const int8_t *message) {
  
  if (message != NULL) {      
    (void)fprintf(stdout, "%s", message);  // Scrive il messaggio su stdout
  }
}

// Funzione per stampare un messaggio con un valore intero
void safePrintInt(const int8_t *message, int32_t value) {
  
  int8_t buffer[256];  // Buffer per il messaggio formattato
 
  if (snprintf(buffer, sizeof(buffer), "%s%d\n", message, value) > 0) {
    safePrint(buffer); 
  } else {
    (void)fprintf(stderr, "Error formatting message\n");
  }
}
