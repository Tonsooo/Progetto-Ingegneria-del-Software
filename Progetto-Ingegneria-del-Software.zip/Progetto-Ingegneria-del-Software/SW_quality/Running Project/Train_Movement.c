#include <stdint.h>
#include <stdio.h>
#include "Axle_Counter.h"
#include "Safe_Print.h"

static int32_t checkValueLimits(float64_t value); //Checking and converting to init32_t


// Verifica e restituisce lo stato del binario in base al puntatore passato
int32_t checkStatus(int32_t* ptr) {
  
  if (ptr == NULL) { return -1; }  // Gestione puntatore nullo
  
  float64_t value = controlloStato(ptr);
  return checkValueLimits(value);  // Controllo dei limiti di valore
}


// Gestisce l'arrivo del treno aggiornando il conteggio degli assi
void train_arrives(const int32_t L) {
  
  int32_t status_value = 0;
  if (checkStatus(&status_value) == OCCUPIED) {
    safePrint("safety risk"); // Rischio di sicurezza se il binario � gi� occupato
    return; 
    //Ho rimosso il codice successivo dato che non verr� mai eseguito
  }
  for (int32_t l = 0; l < L; l++) { first_axle_counter_pushed(); }
}


// Gestisce la partenza del treno aggiornando il conteggio degli ass
void train_leaves(int32_t x) {
  for (int32_t a = 0; a < x; a++) { second_axle_counter_pushed(); }
}


// Funzione per controllare i limiti di valore
static int32_t checkValueLimits(float64_t value) {
  
  int32_t converted_state = 0;
  
  if (value > INT32_MAX) { converted_state = INT32_MAX; }       // Gestisce overflow
  else if (value < INT32_MIN) { converted_state = INT32_MIN; }  // Gestisce underflow
  else { converted_state = (int32_t)value; }                    // Conversione in int32_t
  
  return converted_state;
}
