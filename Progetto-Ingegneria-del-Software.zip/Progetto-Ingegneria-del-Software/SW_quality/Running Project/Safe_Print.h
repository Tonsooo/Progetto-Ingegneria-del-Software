#ifndef SAFE_PRINT_H
#define SAFE_PRINT_H

#include <stdint.h>  // Include la definizione dei tipi standard come int8_t e int32_t

// External function declarations
extern void safePrint(const int8_t *message);                    // Utilizzata per stampare stringhe su un output sicuro
extern void safePrintInt(const int8_t *message, int32_t value);  // Utile per formattare e stampare messaggi con numeri

#endif /* SAFE_PRINT_H */
