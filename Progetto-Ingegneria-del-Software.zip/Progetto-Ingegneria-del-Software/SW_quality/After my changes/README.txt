Il file CodeCheckResult contiene il risultato del CodeCheck e quindi riporta tutte le violazioni MISRA nel Running Project.

Più del 90% delle violazioni è stato risolto e due delle violazioni riportate sono state giustificate tramite una richiesta di deviazione specifica del file "Train_movement.c".