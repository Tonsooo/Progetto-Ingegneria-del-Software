Nel punto 1.5 l'immagine dell'Use Case Diagram non è stata inserita in quanto poco visibile; ma risulta presente come immagine in PNG all'interno di questa cartella.
